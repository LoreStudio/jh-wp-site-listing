<div class="wrap">
	<h1 id="add-new-user">
		<?php _e( 'Access denied', 'store-location' );?>
	</h1>
	<p>
		<?php _e( 'Sorry you do not have permission to access this page', 'store-location' );?>
	</p>
</div> 